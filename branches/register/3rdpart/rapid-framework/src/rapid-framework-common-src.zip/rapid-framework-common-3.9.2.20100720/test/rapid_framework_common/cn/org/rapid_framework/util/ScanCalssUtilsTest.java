package cn.org.rapid_framework.util;

//import java.util.List;
//
import junit.framework.TestCase;

public class ScanCalssUtilsTest extends TestCase {
      
	 public void test2() {
    	  
     }
      
//    public void test() throws Exception {
//        generateTestByPackage("cn.org.rapid_framework.util**");
//    }
//
//    public void generateTestByPackage(String packageName) throws ClassNotFoundException,Exception {
//        List<String> classes = ScanClassUtils.scanPackages(packageName);
//        System.out.println(classes);
//        for(String className:classes){
//            Class clazz = Class.forName(className);
//            new GeneratorFacade().generateByClass(clazz, "template_clazz");
//        }
//        
//        Runtime.getRuntime().exec("cmd.exe /c start "+GeneratorProperties.getRequiredProperty("outRoot"));
//
//    }
}
