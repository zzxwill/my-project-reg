package cn.org.rapid_framework.test.util.testbean;

public enum SexEnumBean {
    F,M;
}