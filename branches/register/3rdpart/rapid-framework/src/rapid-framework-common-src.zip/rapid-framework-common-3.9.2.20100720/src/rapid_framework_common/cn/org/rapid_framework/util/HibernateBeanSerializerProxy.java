package cn.org.rapid_framework.util;
/**
 * this is marked interface
 * @author badqiu
 *
 */
public interface HibernateBeanSerializerProxy {

}
