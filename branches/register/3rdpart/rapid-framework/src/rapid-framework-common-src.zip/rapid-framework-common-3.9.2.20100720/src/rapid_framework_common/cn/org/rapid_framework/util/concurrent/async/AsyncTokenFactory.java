package cn.org.rapid_framework.util.concurrent.async;
/**
 * 
 * @author badqiu
 * @see DefaultAsyncTokenFactory
 */
@SuppressWarnings("all")
public interface AsyncTokenFactory {
	
	public AsyncToken newToken();
	
}
