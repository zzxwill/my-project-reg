/*
 * Copyright 2002-2005 Robert Breidecker.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sourceforge.jsorter;

/**
 * This class is a wrapper on top of the Boolean class. Its purpose is to
 * provide a class that allows for Boolean values to be sorted, because the
 * Boolean class does not implement the Comparable interface.
 * 
 * @author Robert Breidecker
 */
public final class SortableBoolean implements Comparable {
	/**
	 * The Boolean value being wrapped.
	 */
	private Boolean booleanValue = null;

	/**
	 * Creates a new SortableBoolean object from the input boolean value.
	 * 
	 * @param value
	 *            The boolean value used to create the new SortableBoolean.
	 */
	public SortableBoolean(final boolean value) {
		booleanValue = new Boolean(value);
	}

	/**
	 * Creates a new SortableBoolean object from the input Boolean.
	 */
	public SortableBoolean(final Boolean value) {
		booleanValue = value;
	}

	/**
	 * Creates a new SortableBoolean object from the input String. The new
	 * object will have a true value if the input value is "true", otherwise it
	 * will have a false value.
	 */
	public SortableBoolean(final String value) {
		booleanValue = new Boolean(value);
	}

	/**
	 * Returns the primitive boolean value for this object.
	 * 
	 * @return The primitive boolean value for this object.
	 */
	public boolean booleanValue() {
		return booleanValue.booleanValue();
	}

	/**
	 * Compares this object with the specified object for order. Returns a
	 * negative integer, zero, or a positive integer as this object is less
	 * than, equal to, or greater than the specified object.
	 * 
	 * @param object
	 *            The object to compare this object to.
	 * 
	 * @return A negative integer, zero, or a positive integer as this object is
	 *         less than, equal to, or greater than the specified object.
	 */
	public int compareTo(final Object object) {
		int returnValue = -1;

		if (object == null) {
			throw new IllegalArgumentException(
					"This object can not be compared " + "to a null value.");
		}

		if (!(object instanceof SortableBoolean)) {
			throw new IllegalArgumentException("The input object must be an "
					+ "instance of SortableBoolean.");
		}

		final SortableBoolean compareToBoolean = (SortableBoolean) object;

		if (booleanValue() == false && compareToBoolean.booleanValue() == true) {
			returnValue = -1;
		} else if (booleanValue() == false
				&& compareToBoolean.booleanValue() == false) {
			returnValue = 0;
		} else if (booleanValue() == true
				&& compareToBoolean.booleanValue() == true) {
			returnValue = 0;
		} else if (booleanValue() == true
				&& compareToBoolean.booleanValue() == false) {
			returnValue = 1;
		}

		return returnValue;
	}

	/**
	 * Returns true if and only if the argument is not null and is a
	 * SortableBoolean object that represents the same boolean value as this
	 * object.
	 * 
	 * @param object
	 *            The object to compare this object to.
	 * 
	 * @return Returns true if the specified object represents the same value as
	 *         this object.
	 */
	public boolean equals(final Object object) {
		if (object == null) {
			return false;
		}

		if (!(object instanceof SortableBoolean)) {
			return false;
		}

		return booleanValue.equals(object);
	}

	/**
	 * Returns a hash code for this object. This method calls the hashCode
	 * method on the Boolean object it is wrapping.
	 * 
	 * @return The hash code for the Boolean object wrapped by this object.
	 */
	public int hashCode() {
		return booleanValue.hashCode();
	}

	/**
	 * Returns a String object representing this object's value. If this object
	 * represents the value true, a string equal to "true" is returned.
	 * Otherwise, a string equal to "false" is returned.
	 * 
	 * @return A string representation of this object.
	 */
	public String toString() {
		return booleanValue.toString();
	}

	/**
	 * Returns the Boolean wrapped by this object.
	 * 
	 * @return The Boolean wrapped by this object.
	 */
	public Boolean getBoolean() {
		return booleanValue;
	}
}