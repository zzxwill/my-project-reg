/*
 * Copyright 2002-2005 Robert Breidecker.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sourceforge.jsorter;

/**
 * This class contains constants used in the JSorter project.
 * 
 * @author Robert Breidecker
 */
public class SorterConstants {
	/**
	 * The constant for the first column position.
	 */
	public static final int FIRST_COLUMN_POSITION = 0;

	/**
	 * The constant for ascending order.
	 */
	public static final int ASCENDING_ORDER = 1;

	/**
	 * The constant for descending order.
	 */
	public static final int DESCENDING_ORDER = 0;

	/**
	 * The constant for stating that null data values are invalid. This is the
	 * default value.
	 */
	public static final int NULLS_ARE_INVALID = 0;

	/**
	 * The constant for stating that null data values are valid and should be
	 * treated as the least of possible values when sorting.
	 */
	public static final int NULLS_ARE_LEAST = 1;

	/**
	 * The constant for stating that null data values are valid and should be
	 * treated as the greatest of possible values when sorting.
	 */
	public static final int NULLS_ARE_GREATEST = 2;
}