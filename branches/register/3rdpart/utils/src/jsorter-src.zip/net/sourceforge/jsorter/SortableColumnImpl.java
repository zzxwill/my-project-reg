/*
 * Copyright 2002-2005 Robert Breidecker.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sourceforge.jsorter;

/**
 * This class represents a column that will be sorted by Sorter, SwingSorter, or
 * SortComparator.
 * 
 * @author Robert Breidecker
 */
public class SortableColumnImpl implements SortableColumn {
	/**
	 * The number position of the column to sort with.
	 */
	private int columnPosition = SorterConstants.FIRST_COLUMN_POSITION;

	/**
	 * The order to sort the column by.
	 */
	private int columnOrder = SorterConstants.ASCENDING_ORDER;

	/**
	 * The name of the sort column.
	 */
	private String columnName = null;

	/**
	 * SortColumn constructor. The constructor will set both the column number
	 * and the column order.
	 * 
	 * @param columnPosition
	 *            The number position of the column in the data to sort by.
	 *            Column numbers start at zero for the first column.
	 * 
	 * @param columnOrder
	 *            This value will be used for specifying the order in which the
	 *            column sorted by. Sort order can either be ascending or
	 *            descending. The ASCENDING_ORDER and DESCENDING_ORDER constants
	 *            in the Sorter class should be used for this value.
	 */
	public SortableColumnImpl(final int columnPosition, final int columnOrder) {
		this(columnPosition, columnOrder, null);
	}

	/**
	 * SortColumn constructor. The constructor will set both the column number,
	 * the column order and the column name.
	 * 
	 * @param columnPosition
	 *            The number position of the column in the data to sort by.
	 *            Column numbers start at zero for the first column.
	 * 
	 * @param columnOrder
	 *            This value will be used for specifying the order in which the
	 *            column sorted by. Sort order can either be ascending or
	 *            descending. The ASCENDING_ORDER and DESCENDING_ORDER constants
	 *            in the Sorter class should be used for this value.
	 * 
	 * @param columnName
	 *            A name or description for the column. This field only needs to
	 *            be specified if you are planning to display information about
	 *            the column to the user or want to use the name as an
	 *            identifier for the column. If you do not want to use this
	 *            field, you can pass null in as a value.
	 */
	public SortableColumnImpl(final int columnPosition, final int columnOrder,
			final String columnName) {
		this.columnPosition = columnPosition;
		this.columnOrder = columnOrder;
		this.columnName = columnName;
	}

	/**
	 * Returns the number position of the column to sort with.
	 * 
	 * @return The number position of the column to sort with.
	 */
	public int getColumnPosition() {
		return columnPosition;
	}

	/**
	 * Returns the order to sort the column by.
	 * 
	 * @return The order to sort the column by.
	 */
	public int getColumnOrder() {
		return columnOrder;
	}

	/**
	 * Returns the name of this column.
	 * 
	 * @return The name of this column.
	 */
	public String getColumnName() {
		return columnName;
	}
}